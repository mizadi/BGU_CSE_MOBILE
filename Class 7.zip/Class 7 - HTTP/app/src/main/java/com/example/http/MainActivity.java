package com.example.http;

import android.app.Activity;
import android.app.ProgressDialog;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpRequestBase;
import org.apache.http.impl.client.DefaultHttpClient;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.StringWriter;

/*
The application sets an HTTP request to the requested URL and put the answer into a TextView.
 */

public class MainActivity extends Activity {

	Handler handler;

	/*can set your url here*/

	String url = "http://csestudentsdemo.appspot.com/getComment";
	TextView tv;
	ProgressDialog dialog;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		tv = (TextView)findViewById(R.id.textview);

		Button button = (Button)findViewById(R.id.button1);
		button.setOnClickListener(new OnClickListener() {

			public void onClick(View v) {
				
				dialog = ProgressDialog.show(MainActivity.this, "Loading...", "Please wait");
				
				//from android 4, cannot perform network operation on the main thread!
				//if you try to that you'll get: "android.os.NetworkOnMainThreadException"


				//Creating a new thread for the Http call (DO NOT PUT NETWORK ACTIONS ON UI THREAD).
				new Thread(new Runnable() {
					
					public void run() {
						getHttpResponse();
					}
				}).start();				
			}
		});

		handler = new Handler(){
			@Override
			public void handleMessage(Message msg) {
				dialog.dismiss();
				boolean success = msg.getData().getBoolean("success");
				if (success){
					String res = msg.getData().getString("result");
					tv.setText("RESPONSE:     " + res);
				} else {
					tv.setText("RESPONSE:     failed!!!" );
				}
				
			}
		};


	}


	/*
	The function send the http call to the url requested and manipulating the answer from the server.
	 */
	private void getHttpResponse(){
		//Creating the main object DeafultHttpClinet from the Apache library.
		DefaultHttpClient httpClient = new DefaultHttpClient();
		//Creating the Request, setting the url we're requesting from.
		HttpRequestBase httpRequest = new HttpGet(url);
		//The following object will contain the answer from the server.
		HttpResponse response;

		//Message will be delivered back to the UI THREAD from this thread.
		Message msg = handler.obtainMessage();
		Bundle bundle = new Bundle();
		
		try {
			//Here we execute the Http request to the server , we send the httpRequest that holds the url we're requesting from.
			response = httpClient.execute(httpRequest);
			//Manipulating the response from the server.
			String res = resualtToString(response);    	
			
			bundle.putBoolean("success", true);
			bundle.putString("result", res);
			
		} catch (ClientProtocolException e) {
			bundle.putBoolean("success", false);
		} catch (IOException e) {
			bundle.putBoolean("success", false);
		}
		//Setting the bundle results into the message.
		msg.setData(bundle);
		//Sending the message back to the UI thread with the handler.
		handler.sendMessage(msg);
	}

	/*
	The function manipulates the response from the http request the get the payload from it.
	@param - response - contains the http request answer.
	 */
	private String resualtToString(HttpResponse response) throws IOException {
		StringWriter writer = new StringWriter();
		// response.getEntity().getContent() will return the payload from the HTTP request.
		Reader reader = new BufferedReader(new InputStreamReader(response.getEntity().getContent(), "UTF-8"));
		int r;
		while ((r = reader.read()) != -1) {
			writer.write(r);
		}
		return writer.toString();
	}
	
	
}
