package com.javacodegeeks.android.androidsocketclient;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
/*
The application acts as the client to demonstrate sockets communication.
It opens a TCP socket on the requested ip and port, when clicking the send button
it sends the content of the edit text to the socket.
 */
public class Client extends Activity {

	private Socket socket;

	//Setting server port and IP.
	private static final int SERVERPORT = 6000;
	private static final String SERVER_IP = "127.0.0.1";

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);		

		/*
		The socket opens once the application is created.
		Everytime you trigger a click on the send button the application sends to the socket
		the content you put into the EditText.
		 */

		//Creating a new thread for the socket (DO NOT open socket on the UI Thread)
		new Thread(new ClientThread()).start();
	}

	/*
	The function triggers click on the send buttom we created in the activity's xml.
	 */
	public void onClick(View view) {
		try {
			EditText et = (EditText) findViewById(R.id.EditText01);
			String str = et.getText().toString();
			//We create a printwriter no the socket it self to write to it
			PrintWriter out = new PrintWriter(new BufferedWriter(
					new OutputStreamWriter(socket.getOutputStream())),
					true);
			//prints (sends) content to the socket.
			out.println(str);
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	class ClientThread implements Runnable {

		@Override
		public void run() {
			
			try {
				//Getting the name from the ip, this is requried to open the scoket.
				InetAddress serverAddr = InetAddress.getByName(SERVER_IP);

				//Starting the socket using the name from ip and the port number.
				socket = new Socket(serverAddr, SERVERPORT);

				//Handling errors.
			} catch (UnknownHostException e1) {
				e1.printStackTrace();
			} catch (IOException e1) {
				e1.printStackTrace();
			}

		}

	}
}