package com.javacodegeeks.android.androidsocketserver;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;

/*
The application acts as the server for the demonstration of Socksets, it opens a welcome socket
When a client connect it opens a TCP socket for content.
 */
public class Server extends Activity {

	private ServerSocket serverSocket;

	Handler updateConversationHandler;

	Thread serverThread = null;

	private TextView text;



	public static final int SERVERPORT = 6000;

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);

		text = (TextView) findViewById(R.id.text2);

		//Handler to handle the messages from the clinet back to the UI Thread.
		updateConversationHandler = new Handler();

		//Creating a new thread to open the welcome/accept socket.
		this.serverThread = new Thread(new ServerThread());
		this.serverThread.start();

	}

	@Override
	protected void onStop() {
		super.onStop();
		try {
			serverSocket.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	class ServerThread implements Runnable {

		public void run() {
			Socket socket = null;
			try {
				//Creating a new socket for the welcome socket.
				serverSocket = new ServerSocket(SERVERPORT);

				//Handling errors.
			} catch (IOException e) {
				e.printStackTrace();
			}
			//The while loop keeps running as long as the current thread is running.
			while (!Thread.currentThread().isInterrupted()) {

				try {

					//The socket listens here, it waits for clients who wants to connect with it
					socket = serverSocket.accept();


					//When a client connected we're opening a new communication thread in order to communicate with it
					//We're creating new communication socket for each client that connects to the welcome socket.
					CommunicationThread commThread = new CommunicationThread(socket);
					new Thread(commThread).start();

					//Handling errors.
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}

	class CommunicationThread implements Runnable {

		private Socket clientSocket;

		private BufferedReader input;

		public CommunicationThread(Socket clientSocket) {


			//creating a new socket for communication.
			this.clientSocket = clientSocket;

			try {

				//creating a new buffer reader that gets the content from the socket for as long as the socket is open.
				this.input = new BufferedReader(new InputStreamReader(this.clientSocket.getInputStream()));

				//Handling errors.
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

		public void run() {
			

			//While our communication thread is alive
			while (!Thread.currentThread().isInterrupted()) {

				try {
					//gets the line from the buffer reader.
					String read = input.readLine();

					//Handler posts the content of the string to the activity.
					updateConversationHandler.post(new updateUIThread(read));

					//Handling Errors
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

	}

	class updateUIThread implements Runnable {
		private String msg;

		//set the string into msg object
		public updateUIThread(String str) {
			this.msg = str;
		}

		@Override
		//Puts the content of the msg into the TextView in the Activity.
		public void run() {
			text.setText(text.getText().toString()+"Client Says: "+ msg + "\n");
		}

	}

}