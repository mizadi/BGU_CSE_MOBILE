package com.example.adimizrahi.fragmentsexample;

import android.os.Bundle;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setFragment(0);

    }

    private void setFragment(int i) {
        FragmentEx frag = new FragmentEx();
        Bundle bundle = new Bundle();
        bundle.putInt("whichFragment",i);
        frag.setArguments(bundle);
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.fragment_container, frag);
        transaction.addToBackStack(null);
        transaction.commit();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    //Buttons clicks handler
    public void changeFragment (View view){
        //Created a switch to tell between the different buttons and load the right fragment.
        switch(view.getId()){
            case R.id.firstFragmentButton: {
                setFragment(0);
                break;
            }
            case(R.id.secondFragmentButton):{
                setFragment(1);
                break;
            }
            case(R.id.thirdFragmentButton):{
                setFragment(2);
                break;
            }
            default:{

            }
        }
    }
}
