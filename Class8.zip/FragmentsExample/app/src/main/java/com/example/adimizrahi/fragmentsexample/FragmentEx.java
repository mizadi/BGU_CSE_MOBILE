package com.example.adimizrahi.fragmentsexample;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

/**
 * Created by adimizrahi on 13/12/2015.
 */
public class FragmentEx extends Fragment {
    int fragNumber = 0 ;
    int[] fragmentLayouts= {R.layout.first_fragment,R.layout.second_fragment,R.layout.third_fragment};
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        Bundle bundle = getArguments();
        if(bundle!=null) {
             fragNumber = bundle.getInt("whichFragment");
        }
        return inflater.inflate(fragmentLayouts[fragNumber], container, false);
    }
}
