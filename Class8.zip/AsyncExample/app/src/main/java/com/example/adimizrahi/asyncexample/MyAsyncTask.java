package com.example.adimizrahi.asyncexample;

import android.os.AsyncTask;
import android.util.Log;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

/**
 * Created by adimizrahi on 12/12/2015.
 */
public class MyAsyncTask extends AsyncTask<String,Void,String> {
    HttpURLConnection http ;
    String url;
    AsyncTaskInterface interFace;

    //Constructor
    public MyAsyncTask(AsyncTaskInterface interFace){
        //We set the interface here
        this.interFace = interFace;
    }

    @Override
    protected String doInBackground(String... params) {
        try {
            //Get the url from the params sent on execute().
            URL url = new URL(params[0]);
            //Open HttpUrlConnection with the url asked.
            http = (HttpURLConnection) url.openConnection();
            try {
                BufferedReader br = new BufferedReader(new InputStreamReader(http.getInputStream()));
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = br.readLine()) != null) {
                    sb.append(line+"\n");
                }
                br.close();
                return sb.toString();


            } catch (MalformedURLException e) {
                e.printStackTrace();
            } finally {
                //Close the http connection when done.
                http.disconnect();
            }
            return null;
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return "No response";
    }

        @Override
    protected void onPreExecute (){
        //Before the async task starts running
        Log.d("AsyncTask","Running onPreExecute method!");


    }
    @Override
    protected void onPostExecute (String result){
        //When doInBackground is finished we send the result back to the activity via the interface.
        Log.d("AsyncTask","Running onPostExecute method!");
        interFace.onProcessFinish(result);

    }


}
