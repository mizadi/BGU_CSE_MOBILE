package com.example.adimizrahi.asyncexample;

/**
 * Created by adimizrahi on 12/12/2015.
 */
public interface AsyncTaskInterface {
    public void onProcessFinish(String result);
}
