/** Automatically generated file. DO NOT MODIFY */
package bgu.android.class3;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}