package com.bgu.cse.mobile.programming.lec1.innerClass;

public interface InnerClass {
	public EvenIterator evenIterator();
}
