package com.bgu.cse.mobile.programming.lec1.innerClass;

interface EvenIterator {
	boolean hasNext();
	int getNext();
}
